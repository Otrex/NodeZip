const express = require('express');

const http = require('http')

const path = require('path')

const socketio = require('socket.io')


const app = express();
const server = http.createServer(app)
const io = socketio(server)

app.use(express.static(path.join(__dirname, 'public')))


const fMsg = require('./format/message')
user = "Bot"

io.on('connection', socket => {
	socket.on('joinroom', (user)=>{
		socket.join(user)
		msg = fMsg(msg.sender, msg.msg)
		io.emit('message', msg)
		socket.broadcast.to(user)
		.
	})

	socket.on('connected',(msg)=>{
		user = msg
		users.push(msg)
		io.emit('users', users)
	})
	console.log("New websocket connecton...")

	socket.emit('message', "welcome User")


	// Brocast to all when user connects
	socket.broadcast.emit("message", user + ' Has Joined')

	// Disconnects
	socket.on("disconnect", ()=>{
		io.emit('message', user + " A user has left the chat")
	})

	// Get chatMessage
	socket.on('chatMessage', (msg)=>{
		console.log(msg)
		msg = fMsg(msg.sender, msg.msg)
		io.emit('message', msg)
	})
})
const PORT = 3000 || process.env.PORT;

server.listen(PORT, ()=>console.log(`Server is running on port ${PORT}`))