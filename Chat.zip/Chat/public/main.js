const socket = io();

const get = (el) =>{
	return document.querySelector(el)
}

var infopanel = get(".info-panel")
var msgbox = get(".message-box")
var sendbtn = get("#sendbtn")
var msg = get("#msg")
var me = get("#me")
var users = get(".userslist")

me.value = Math.floor(Math.random(100)*10) + 'Pi '
msgbox.innerHTML = ""

socket.emit('connected', me.value)
socket.on('users', (msg)=>{
	console.log(msg) 
	users.innerHTML = ""
	msg.forEach((user)=>{
		users.innerHTML  += `<li> ${user} </li>`
	})
})


function msgTag(parent, msg, sender, date){
	var chatbox = document.createElement('div')
	chatbox.setAttribute('class', 'chat')
	var who = document.createElement('div')
	if (me.value === sender){
		who.setAttribute('class', 'me chat-msg')
	} else {
		who.setAttribute('class', 'them chat-msg')
	}
	var span = document.createElement('span')
	span.setAttribute('id', 'name')
	span.innerHTML = sender
	var datespan = document.createElement('span')
	datespan.setAttribute('id', 'name')
	datespan.innerHTML = date

	var p = document.createElement('p')
	p.setAttribute('class', 'themsg')
	p.innerHTML = msg

	who.appendChild(span)
	who.appendChild(datespan)
	who.appendChild(p)

	chatbox.appendChild(who)
	parent.appendChild(chatbox)
}


socket.on('message', message=>{
	if (typeof message != 'object'){
		infopanel.innerHTML = message;
	} else {
		if (message.sender != me.value){
			alert(message.sender+ " Sent a message...")
		}
		

		msgTag(msgbox, message.msg, message.sender, message.time)
		msgbox.scrollTop = msgbox.scrollHeight;
	}
})

msg.addEventListener('keyup', (e)=>{
	if (e.keyCode == 13){
		e.preventDefault()
		if (msg.value != ''){
			socket.emit('chatMessage', {sender: me.value, msg: msg.value})
			msg.value = ''
			msg.focus()
		} else {
			infopanel.innerHTML = "Can't Send empty message"
		}
	}
})

sendbtn.addEventListener('click', (e) =>{
	e.preventDefault()
	if (msg.value != ''){
		socket.emit('chatMessage', {sender: me.value, msg: msg.value})
		msg.value = ''
		msg.focus()
	} else {
		infopanel.innerHTML = "Can't Send empty message"
	}
})
