const moment = require('moment')

function formatMsg( sender, msg) {
	return {
		sender,
		msg,
		time: moment().format('h:mm a')
	}
}

module.exports = formatMsg